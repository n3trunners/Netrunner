package com.jarves.mh.runtime

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AntigravityBridgeTest {
    @Test
    fun `init event exposes conversation id before task completion`() {
        val event = AntigravityEventParser.parse(
            """{"event":"init","conversation_id":"conversation-early","init":{"model":"gemini"}}""",
        )
        assertEquals(AntigravityParsedEvent.Initialized("conversation-early"), event)
    }

    @Test
    fun `parses streamed response deltas`() {
        val parsed = AntigravityEventParser.parse(
            """{"event":"step_update","step_update":{"state":"ACTIVE","step_type":"agent_response","text_delta":"hello"}}""",
        )
        assertTrue(parsed is AntigravityParsedEvent.Text)
        assertEquals("hello", (parsed as AntigravityParsedEvent.Text).value)
    }

    @Test
    fun `parses successful result and conversation id`() {
        val parsed = AntigravityEventParser.parse(
            """{"event":"result","result":{"conversation_id":"conversation-1","status":"SUCCESS","response":"done"}}""",
        )
        assertTrue(parsed is AntigravityParsedEvent.Result)
        val result = parsed as AntigravityParsedEvent.Result
        assertEquals("conversation-1", result.conversationId)
        assertEquals("SUCCESS", result.status)
        assertEquals("done", result.response)
        assertNull(result.error)
    }

    @Test
    fun `shows the command from official tool info`() {
        val parsed = AntigravityEventParser.parse(
            """{"event":"step_update","step_update":{"state":"ACTIVE","step_type":"tool","tool_name":"run_command","tool_info":{"name":"run_command","parameters":{"CommandLine":"python3 hello.py"}}}}""",
        )
        assertEquals(
            AntigravityParsedEvent.ToolStarted("Bash", "python3 hello.py"),
            parsed,
        )
    }

    @Test
    fun `shows the target path from official write tool info`() {
        val parsed = AntigravityEventParser.parse(
            """{"event":"step_update","step_update":{"state":"DONE","step_type":"tool","tool_name":"write_to_file","tool_info":{"name":"write_to_file","parameters":{"TargetFile":"/workspace/app/main.py"}}}}""",
        )
        assertEquals(
            AntigravityParsedEvent.ToolCompleted("Write", "/workspace/app/main.py"),
            parsed,
        )
    }

    @Test
    fun `shows completed command output instead of repeating command`() {
        val parsed = AntigravityEventParser.parse(
            """{"event":"step_update","step_update":{"state":"DONE","step_type":"tool","tool_name":"run_command","tool_info":{"name":"run_command","parameters":{"CommandLine":"gradle assembleDebug"},"output":"Preparing\r\nBUILD SUCCESSFUL\r\n"}}}""",
        )
        assertEquals(
            AntigravityParsedEvent.ToolCompleted("Bash", "Preparing\nBUILD SUCCESSFUL"),
            parsed,
        )
    }

    @Test
    fun `shows tool errors as completed activity`() {
        val parsed = AntigravityEventParser.parse(
            """{"event":"step_update","step_update":{"state":"ERROR","step_type":"tool","tool_name":"run_command","tool_info":{"name":"run_command","parameters":{"CommandLine":"gradle assembleDebug"},"error":{"type":"TOOL_ERROR","message":"context canceled"}}}}""",
        )
        assertEquals(
            AntigravityParsedEvent.ToolCompleted("Bash", "context canceled"),
            parsed,
        )
    }

    @Test
    fun `ignores unknown and malformed events`() {
        assertNull(AntigravityEventParser.parse("not json"))
        assertNull(AntigravityEventParser.parse("""{"event":"future_event","payload":{}}"""))
    }

    @Test
    fun `extracts a wrapped Google PKCE url`() {
        val output = """
            Your browser should open automatically. If not:
            https://accounts.google.com/o/oauth2/auth?access_type=offline&client_id=client.apps.googleusercontent.com&code_chall
            enge=challenge&code_challenge_method=S256&state=fresh-state
            If you aren't automatically redirected, paste the authorization code below:
        """.trimIndent()
        val url = extractGoogleOAuthUrl(output)
        assertTrue(url!!.startsWith("https://accounts.google.com/"))
        assertTrue("client_id=client.apps.googleusercontent.com" in url)
        assertTrue("code_challenge=challenge" in url)
        assertTrue("state=fresh-state" in url)
    }

    @Test
    fun `oauth url excludes terminal labels appended after state`() {
        val output = """
            https://accounts.google.com/o/oauth2/auth?access_type=offline&client_id=client.apps.googleusercontent.com&code_chall
            enge=challenge&code_challenge_method=S256&prompt=consent&state=eqPPegReyKP37OxuRsM0EQ
            ──────────────────────────────────────────────────
            Copy and paste the URL or click on the link below:
            → Click here to authenticate
            After authenticating, copy the code displayed in the browser and paste it below:
            authorization code... shift+up/down Navigate
        """.trimIndent()

        assertEquals(
            "https://accounts.google.com/o/oauth2/auth?access_type=offline&client_id=client.apps.googleusercontent.com&code_challenge=challenge&code_challenge_method=S256&prompt=consent&state=eqPPegReyKP37OxuRsM0EQ",
            extractGoogleOAuthUrl(output),
        )
    }

    @Test
    fun `headless command uses exact model configuration without conflicting effort`() {
        val command = antigravityCommand("gemini-model", "high", "conversation-1")
        assertTrue(command.containsAll(listOf(
            "--input-format", "stream-json",
            "--output-format", "stream-json",
            "--print-timeout", "60m",
            "--dangerously-skip-permissions",
            "--model", "gemini-model",
            "--conversation", "conversation-1",
        )))
        assertTrue("--effort" !in command)
        assertTrue("--new-project" !in command)
    }

    @Test
    fun `workspace prompt prevents silent foreground Android builds`() {
        val prompt = antigravityWorkspacePrompt("demo", "Build the app")

        assertTrue("never use plain `gradle build`" in prompt)
        assertTrue("--no-daemon" in prompt)
        assertTrue("--offline" in prompt)
        assertTrue("timeout 5m" in prompt)
        assertTrue("timeout 15m" in prompt)
        assertTrue("no existing debug APK" in prompt)
        assertTrue("existing debug APK" in prompt)
        assertTrue("assembleDebug" in prompt)
        assertTrue("use `manage_task`" in prompt)
        assertTrue("do not use `nohup`" in prompt)
        assertTrue("Never wait silently" in prompt)
    }

    @Test
    fun `Gradle heartbeat reports elapsed time before command output arrives`() {
        val detail = antigravityGradleProgress("gradle assembleDebug", 42_900L)

        assertTrue(detail.startsWith("Gradle is running · 42s"))
        assertTrue("gradle assembleDebug" in detail)
        assertTrue("Full output will appear" in detail)
    }

    @Test
    fun `network timeout during silent auth is not reported as signed out`() {
        val message = antigravityFriendlyError(
            "You are not logged into Antigravity",
            "userinfo request failed: dial tcp: lookup www.googleapis.com: i/o timeout",
        )

        assertEquals(
            "Antigravity could not reach Google. Check your internet or DNS connection, then try again.",
            message,
        )
    }

    @Test
    fun `genuine missing authentication still asks for Google sign in`() {
        assertEquals(
            "Antigravity needs Google sign-in. Open Settings → Coding agent.",
            antigravityFriendlyError("You are not logged into Antigravity"),
        )
    }

    @Test
    fun `new headless conversation creates an official project`() {
        val command = antigravityCommand("", "high", null)
        assertTrue("--new-project" in command)
        assertTrue("--conversation" !in command)
        assertTrue(command.containsAll(listOf("--effort", "high")))
    }

    @Test
    fun `workspace prompt keeps generated files in the mounted project`() {
        val prompt = antigravityWorkspacePrompt("bold-kalam", "Create hello.py")
        assertTrue("/workspace/bold-kalam" in prompt)
        assertTrue("Do not create project output" in prompt)
        assertTrue(prompt.endsWith("Create hello.py"))
    }

    @Test
    fun `sign-in check fails when agy models asks for sign in`() {
        val output = "Fetching available models...\nError: Please sign in to view available models. " +
            "Launch the CLI without arguments to sign in.\n"
        assertEquals(AntigravitySignInCheck.SIGNED_OUT, antigravitySignInCheck(output, 0))
    }

    @Test
    fun `sign-in check fails on headless authentication required`() {
        val output = "Error: authentication required. Run 'agy' to log in, then retry."
        assertEquals(AntigravitySignInCheck.SIGNED_OUT, antigravitySignInCheck(output, 1))
    }

    @Test
    fun `sign-in check passes when models are listed`() {
        val output = "Fetching available models...\ngemini-3.8-flash-medium\ngemini-3.1-pro-high\n"
        assertEquals(AntigravitySignInCheck.SIGNED_IN, antigravitySignInCheck(output, 0))
    }

    @Test
    fun `network failure during sign-in check does not sign out`() {
        val output = "Error: dial tcp: lookup cloudcode-pa.googleapis.com: i/o timeout"
        assertEquals(AntigravitySignInCheck.UNKNOWN, antigravitySignInCheck(output, 1))
    }

    @Test
    fun `invalid conversation project is treated as stale`() {
        val error = "The project associated with this conversation is no longer valid."
        assertTrue(isStaleAntigravityConversation(error))
        assertEquals(
            "The previous Antigravity conversation is no longer available. Send your message again to start a new one.",
            antigravityFriendlyError(error),
        )
    }

    @Test
    fun `missing conversation warning is not treated as stale`() {
        // agy prints this, ignores --conversation and continues on its own.
        assertTrue(!isStaleAntigravityConversation("warning: conversation \"0f0e6a52\" not found"))
    }
}
